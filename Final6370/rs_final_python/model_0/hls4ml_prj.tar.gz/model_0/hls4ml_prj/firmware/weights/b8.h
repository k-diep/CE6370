//Numpy array shape [10]
//Min -1.000000000000
//Max 0.968750000000
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
bias8_t b8[10];
#else
bias8_t b8[10] = {0.18750, 0.28125, -0.56250, -0.62500, 0.28125, 0.96875, -1.00000, -0.03125, -0.46875, 0.28125};
#endif

#endif
