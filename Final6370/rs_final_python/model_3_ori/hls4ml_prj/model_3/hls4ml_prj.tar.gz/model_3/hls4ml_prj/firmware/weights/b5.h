//Numpy array shape [10]
//Min -0.218750000000
//Max 0.781250000000
//Number of zeros 1

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
bias5_t b5[10];
#else
bias5_t b5[10] = {0.15625, 0.53125, 0.34375, 0.00000, 0.09375, 0.03125, 0.53125, 0.78125, -0.12500, -0.21875};
#endif

#endif
