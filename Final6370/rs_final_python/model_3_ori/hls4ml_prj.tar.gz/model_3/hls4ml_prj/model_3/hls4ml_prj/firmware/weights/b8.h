//Numpy array shape [10]
//Min -1.000000000000
//Max 0.968750000000
//Number of zeros 0

#ifndef B8_H_
#define B8_H_

#ifndef __SYNTHESIS__
bias8_t b8[10];
#else
bias8_t b8[10] = {-1.00000, 0.96875, 0.09375, -0.50000, 0.84375, -1.00000, -0.09375, 0.12500, 0.96875, 0.65625};
#endif

#endif
