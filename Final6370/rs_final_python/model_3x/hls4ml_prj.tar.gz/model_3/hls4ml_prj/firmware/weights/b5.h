//Numpy array shape [10]
//Min -0.281250000000
//Max 0.718750000000
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
bias5_t b5[10];
#else
bias5_t b5[10] = {0.71875, -0.15625, 0.21875, -0.28125, 0.15625, 0.25000, 0.31250, 0.28125, -0.12500, 0.06250};
#endif

#endif
